-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Янв 07 2016 г., 09:26
-- Версия сервера: 10.1.8-MariaDB
-- Версия PHP: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ural_ims`
--

-- --------------------------------------------------------

--
-- Структура таблицы `ims_fields`
--

DROP TABLE IF EXISTS `ims_fields`;
CREATE TABLE `ims_fields` (
  `fieldID` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_fields`
--

INSERT INTO `ims_fields` (`fieldID`, `name`, `alias`, `description`, `type`) VALUES
(1, 'Заголовок страницы (title)', 'seo_title', '', 'input'),
(2, 'Ключевые слова (keywords)', 'seo_keywords', '', 'input'),
(3, 'Описание страницы (description)', 'seo_description', '', 'input'),
(4, 'Фаил', 'file', '', 'file'),
(5, 'Изображение', 'image', '', 'image'),
(6, 'Галлерея', 'gallery', '', 'gallery'),
(8, 'Схема проезда', 'map', '', 'image'),
(9, 'Логотип', 'logo', '', 'image'),
(10, 'Название формы', 'form_name', '', 'input'),
(11, 'Контент формы', 'form', '', 'textarea');

-- --------------------------------------------------------

--
-- Структура таблицы `ims_fields_values`
--

DROP TABLE IF EXISTS `ims_fields_values`;
CREATE TABLE `ims_fields_values` (
  `fieldID` int(11) NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_fields_values`
--

INSERT INTO `ims_fields_values` (`fieldID`, `alias`, `value`) VALUES
(1, '_seo_main', 'Заголовок Главной страницы'),
(1, 'test_page', 'Заголовок Тестовой страницы'),
(2, 'test_page', 'Ключевые слова Тестовой страницы'),
(3, 'test_page', 'Мета описание Тестовой страницы'),
(5, '001.jpg', './upload/phpF03F_55cda4ae7fd15.tmp'),
(5, '002.jpg', './upload/phpF04F_55cda4ae7ffa1.tmp'),
(5, '003.jpg', './upload/phpF050_55cda4ae80230.tmp'),
(5, '004.jpg', './upload/phpF051_55cda4ae804b8.tmp'),
(5, '005.jpg', './upload/phpF052_55cda4ae80768.tmp'),
(5, '006.jpg', './upload/phpF073_55cda4ae809e1.tmp'),
(5, '007.jpg', './upload/phpF074_55cda4ae80c71.tmp'),
(5, '008.jpg', './upload/phpF084_55cda4ae80f02.tmp'),
(5, '009.jpg', './upload/phpF095_55cda4ae81194.tmp'),
(5, '010.jpg', './upload/phpF096_55cda4ae81424.tmp'),
(5, '011.jpg', './upload/phpF0A7_55cda4ae816c4.tmp'),
(5, '012.jpg', './upload/phpF0B7_55cda4ae8193c.tmp'),
(5, '013.jpg', './upload/phpF0B8_55cda4ae81baf.tmp'),
(5, '014.jpg', './upload/phpF0C9_55cda4ae81e2d.tmp'),
(5, '015.jpg', './upload/phpF0CA_55cda4ae8210e.tmp'),
(5, '016.jpg', './upload/phpF03E_55cda4ae7fa2d.tmp'),
(5, '017.jpg', './upload/php21BF_55cda4bb268a0.tmp'),
(5, '018.jpg', './upload/php21D0_55cda4bb26b2b.tmp'),
(5, '019.jpg', './upload/php21D1_55cda4bb26da7.tmp'),
(5, '020.jpg', './upload/php21D2_55cda4bb2701f.tmp'),
(5, '021.jpg', './upload/php21E2_55cda4bb2728c.tmp'),
(5, '022.jpg', './upload/php21E3_55cda4bb274f8.tmp'),
(5, '023.jpg', './upload/php2204_55cda4bb27772.tmp'),
(5, '024.jpg', './upload/php2205_55cda4bb279f5.tmp'),
(5, '025.jpg', './upload/php2215_55cda4bb27c75.tmp'),
(5, '026.jpg', './upload/php2216_55cda4bb27ee5.tmp'),
(5, '027.jpg', './upload/php2217_55cda4bb28172.tmp'),
(5, '028.jpg', './upload/php2218_55cda4bb28413.tmp'),
(5, '029.jpg', './upload/php2229_55cda4bb286ab.tmp'),
(5, '030.jpg', './upload/php222A_55cda4bb289f7.tmp'),
(5, '031.jpg', './upload/php222B_55cda4bb28cc7.tmp'),
(5, '032.jpg', './upload/php21BE_55cda4bb265c5.tmp'),
(5, '033.jpg', './upload/php49BA_55cda4c569719.tmp'),
(5, '034.jpg', './upload/php49BB_55cda4c569aeb.tmp'),
(5, '035.jpg', './upload/php49CB_55cda4c569ed7.tmp'),
(5, '036.jpg', './upload/php49CC_55cda4c56a29d.tmp'),
(5, '037.jpg', './upload/php49CD_55cda4c56a626.tmp'),
(5, '038.jpg', './upload/php49DE_55cda4c56aac9.tmp'),
(5, '039.jpg', './upload/php49DF_55cda4c56b043.tmp'),
(5, '040.jpg', './upload/php49F0_55cda4c56b30f.tmp'),
(5, '041.jpg', './upload/php49F1_55cda4c56b599.tmp'),
(5, '042.jpg', './upload/php49F2_55cda4c56b8f1.tmp'),
(5, '043.jpg', './upload/php4A02_55cda4c56bb68.tmp'),
(5, '044.jpg', './upload/php4A23_55cda4c56bdde.tmp'),
(5, '045.jpg', './upload/php4A24_55cda4c56c05c.tmp'),
(5, '046.jpg', './upload/php4A34_55cda4c56c2cd.tmp'),
(5, '047.jpg', './upload/php4A35_55cda4c56c53c.tmp'),
(5, '048.jpg', './upload/php4A36_55cda4c56c7b3.tmp'),
(5, '049.jpg', './upload/php4A47_55cda4c56ca3e.tmp'),
(5, '050.jpg', './upload/php4A48_55cda4c56e2d1.tmp'),
(5, '051.jpg', './upload/php49A9_55cda4c5692dc.tmp'),
(10, 'feedback_form', 'Форма обратной связи'),
(10, 'feedback_form_3', 'Форма обратной связи 3'),
(11, 'feedback_form', '<form class="feedback-form">\n<div class="form-group">\n  <dl>\n    <dt><label for="name">Имя</label></dt>\n	<dd><input id="name" type="text" class="form-control" placeholder="Имя"></dd>\n  </dl>\n</div>\n                            \n<div class="form-group">\n  <dl>\n    <dt><label for="email">Email</label></dt>\n	<dd><input id="email" type="text" class="form-control" placeholder="Email"></dd>\n  </dl>\n</div><div class="form-group">\n  <dl>\n    <dt><label for="phone">Телефон</label></dt>\n	<dd><input id="phone" type="text" class="form-control" placeholder="+7 (912) 123-45-67"></dd>\n  </dl>\n</div><div class="form-group">\n  <dl>\n    <dt><label for="message">Текст сообщения</label></dt>\n	<dd><textarea id="message" placeholder="Сообщение..."></textarea></dd>\n  </dl>\n</div><div class="form-group">\n  <input type="submit" value="Отправить">\n</div>\n</form>'),
(11, 'feedback_form_3', '<form class="feedback-form">\r\n<div class="form-group">\r\n  <dl>\r\n    <dt><label for="name">Имя</label></dt>\r\n	<dd><input id="name" type="text" class="form-control" placeholder="Имя"></dd>\r\n  </dl>\r\n</div>\r\n                            \r\n<div class="form-group">\r\n  <dl>\r\n    <dt><label for="email">Email</label></dt>\r\n	<dd><input id="email" type="text" class="form-control" placeholder="Email"></dd>\r\n  </dl>\r\n</div><div class="form-group">\r\n  <dl>\r\n    <dt><label for="phone">Телефон</label></dt>\r\n	<dd><input id="phone" type="text" class="form-control" placeholder="+7 (912) 123-45-67"></dd>\r\n  </dl>\r\n</div><div class="form-group">\r\n  <dl>\r\n    <dt><label for="message">Текст сообщения</label></dt>\r\n	<dd><textarea id="message" placeholder="Сообщение..."></textarea></dd>\r\n  </dl>\r\n</div><div class="form-group">\r\n  <input type="submit" value="Отправить">\r\n</div>\r\n</form>');

-- --------------------------------------------------------

--
-- Структура таблицы `ims_pages`
--

DROP TABLE IF EXISTS `ims_pages`;
CREATE TABLE `ims_pages` (
  `pageID` int(11) NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `formName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_pages`
--

INSERT INTO `ims_pages` (`pageID`, `alias`, `name`, `content`, `formName`, `active`, `date`) VALUES
(1, 'test_page', 'Тестовая страница', '<p>К сожалению, такой страницы не существует. Возможно вы набрали неправильный адрес, или перешли на страницу, которая была перемещена или удалена. Попробуйте начать поиск необходимой информации заново с <a href="{base_url}" title="Петровский">главной страницы</a> сайта</p>\r\n<p>К сожалению, такой страницы не существует. Возможно вы набрали неправильный адрес, или перешли на страницу, которая была перемещена или удалена. Попробуйте начать поиск необходимой информации заново с <a href="{server_url}{base_url}" title="Петровский">главной страницы</a> сайта</p>\r\n<p>К сожалению, такой страницы не существует. Возможно вы набрали неправильный адрес, или перешли на страницу, которая была перемещена или удалена. Попробуйте начать поиск необходимой информации заново с <a href="{server_url}{base_url}" title="Петровский">главной страницы</a> сайта</p>\r\n<p>К сожалению, такой страницы не существует. Возможно вы набрали неправильный адрес, или перешли на страницу, которая была перемещена или удалена. Попробуйте начать поиск необходимой информации заново с <a href="{server_url}{base_url}" title="Петровский">главной страницы</a> сайта</p>', 'feedback_form', '1', '2015-08-25 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `ims_sensors`
--

DROP TABLE IF EXISTS `ims_sensors`;
CREATE TABLE `ims_sensors` (
  `sensorID` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL,
  `active` varchar(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_sensors`
--

INSERT INTO `ims_sensors` (`sensorID`, `name`, `description`, `alias`, `weight`, `active`) VALUES
(1, 'Формы для связи', 'Все действия с формами на сайте', 'forms', 1, '1'),
(2, 'Подписки', 'Сенсоры для подписок', 'subscriptions', 2, '1'),
(3, 'Ссылки на скачивание', 'Ссылки на скачивание презентаций и предложений', 'download', 3, '1');

-- --------------------------------------------------------

--
-- Структура таблицы `ims_sensor_calls`
--

DROP TABLE IF EXISTS `ims_sensor_calls`;
CREATE TABLE `ims_sensor_calls` (
  `callID` int(11) NOT NULL,
  `signalID` int(11) NOT NULL,
  `sensorID` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_sensor_calls`
--

INSERT INTO `ims_sensor_calls` (`callID`, `signalID`, `sensorID`, `date`) VALUES
(1, 1, 1, '2015-07-25 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `ims_sensor_signals`
--

DROP TABLE IF EXISTS `ims_sensor_signals`;
CREATE TABLE `ims_sensor_signals` (
  `signalID` int(11) NOT NULL,
  `sensorID` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `mainPageDescription` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL,
  `active` varchar(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_sensor_signals`
--

INSERT INTO `ims_sensor_signals` (`signalID`, `sensorID`, `name`, `description`, `mainPageDescription`, `alias`, `weight`, `active`) VALUES
(1, 1, 'Отзыв', 'Срабатывает, когда посетитель отправляет отзыв из формы обратной связи.', 'Отзывов', 'feedback_send', 1, '1'),
(2, 1, 'Резюме', 'Срабатывает, когда посетитель отправляет резюме из формы откликнуться на вакансию.', 'Резюме', 'cv_recieve', 2, '1'),
(3, 2, 'Подписка', 'Срабатывает при добавлении новой подписки', 'Подписок', 'subscription_add', 1, '1'),
(4, 3, 'Скачать презентацию рекламодателя', 'Срабатывает, когда посетитель скачивает презентацию рекламодателя.', 'Скачать презентацию<br/>рекламодателя', 'advertiser', 1, '1'),
(5, 3, 'Скачать заявку на размещение рекламы', 'Срабатывает, когда посетитель скачивает заявку на размещение рекламы', 'Скачать заявку<br/>на размещение рекламы', 'adv_request', 2, '1'),
(6, 3, 'Скачать презентацию арендодателя', 'Срабатывает, когда посетитель скачивает презентацию арендодателя', 'Скачать презентацию<br/>арендодателя', 'client_presentation', 3, '1');

-- --------------------------------------------------------

--
-- Структура таблицы `ims_settings`
--

DROP TABLE IF EXISTS `ims_settings`;
CREATE TABLE `ims_settings` (
  `settingID` int(11) NOT NULL,
  `groupID` int(11) NOT NULL,
  `headerName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `htmlControlType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_settings`
--

INSERT INTO `ims_settings` (`settingID`, `groupID`, `headerName`, `name`, `value`, `htmlControlType`, `weight`) VALUES
(1, 1, 'Заголовок сайта', 'main_title', 'Запчасти для иномарок в Саратове', 'input', 1),
(2, 2, 'Эл. адрес для отправки отчетов об ошибках на сайте', 'email_for_error_reporting', 'support@lab-itec.ru', 'input', 1),
(3, 3, 'Тема письма', 'newsletter_theme', 'Рассылка новостей компании {Name} {domain}', 'input', 1),
(4, 3, 'Текст письма', 'newsletter_body', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">\r\n<head>\r\n	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n	<title>Компания «Фудсервис»</title>	\r\n</head> \r\n<body style="background-color: #1A1616; margin: 0; padding: 0;">\r\n	{newsletter_header}\r\n	{newsletter_text}\r\n	{email_uid}\r\n</body>\r\n</html>', 'textarea', 2),
(5, 4, 'Кнопка Like для Vkontakte', 'social_vk_button_like', '<div id="vk_like"></div>\r\n<script type="text/javascript">\r\n$(document).bind("loadVkApiLike", function(e){\r\n  VK.init({apiId: VK_APP_ID, onlyWidgets: true});\r\n   VK.Widgets.Like("vk_like", {type: "mini"});\r\n});\r\n</script>', 'textarea', 1),
(6, 1, 'Включить LockScreen', 'lockscreen_enabled', '0', 'checkbox', 2),
(7, 1, 'Время ожидания LockScreen (сек)', 'lockscreen_timeout', '600', 'input', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `ims_settings_groups`
--

DROP TABLE IF EXISTS `ims_settings_groups`;
CREATE TABLE `ims_settings_groups` (
  `groupID` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_settings_groups`
--

INSERT INTO `ims_settings_groups` (`groupID`, `name`, `weight`) VALUES
(1, 'Параметры сайта', 1),
(2, 'Автоматические письма', 2),
(3, 'Рассылка', 3),
(4, 'Социальные кнопки и виджеты', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `ims_users`
--

DROP TABLE IF EXISTS `ims_users`;
CREATE TABLE `ims_users` (
  `userId` int(11) NOT NULL,
  `userName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userFullName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userEmail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userPassword` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userRoleId` int(11) NOT NULL,
  `userActive` tinyint(1) NOT NULL,
  `userRegistrationDate` datetime NOT NULL,
  `userEmailConfirmed` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ims_users`
--

INSERT INTO `ims_users` (`userId`, `userName`, `userFullName`, `userEmail`, `userPassword`, `userRoleId`, `userActive`, `userRegistrationDate`, `userEmailConfirmed`) VALUES
(1, 'MefisTofel', 'Новоселов Александр', 'iviefistofel@gmail.com', 'ae50a96b5a07506d45ddb5bf66348d2d', 1, 1, '2015-08-08 00:00:00', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `ims_fields`
--
ALTER TABLE `ims_fields`
  ADD PRIMARY KEY (`fieldID`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Индексы таблицы `ims_fields_values`
--
ALTER TABLE `ims_fields_values`
  ADD PRIMARY KEY (`fieldID`,`alias`),
  ADD UNIQUE KEY `fieldID` (`fieldID`,`alias`);

--
-- Индексы таблицы `ims_pages`
--
ALTER TABLE `ims_pages`
  ADD PRIMARY KEY (`pageID`);

--
-- Индексы таблицы `ims_sensors`
--
ALTER TABLE `ims_sensors`
  ADD PRIMARY KEY (`sensorID`);

--
-- Индексы таблицы `ims_sensor_calls`
--
ALTER TABLE `ims_sensor_calls`
  ADD PRIMARY KEY (`callID`);

--
-- Индексы таблицы `ims_sensor_signals`
--
ALTER TABLE `ims_sensor_signals`
  ADD PRIMARY KEY (`signalID`);

--
-- Индексы таблицы `ims_settings`
--
ALTER TABLE `ims_settings`
  ADD PRIMARY KEY (`settingID`);

--
-- Индексы таблицы `ims_settings_groups`
--
ALTER TABLE `ims_settings_groups`
  ADD PRIMARY KEY (`groupID`);

--
-- Индексы таблицы `ims_users`
--
ALTER TABLE `ims_users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `ims_fields`
--
ALTER TABLE `ims_fields`
  MODIFY `fieldID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `ims_pages`
--
ALTER TABLE `ims_pages`
  MODIFY `pageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `ims_sensors`
--
ALTER TABLE `ims_sensors`
  MODIFY `sensorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `ims_sensor_calls`
--
ALTER TABLE `ims_sensor_calls`
  MODIFY `callID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `ims_sensor_signals`
--
ALTER TABLE `ims_sensor_signals`
  MODIFY `signalID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `ims_settings`
--
ALTER TABLE `ims_settings`
  MODIFY `settingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `ims_settings_groups`
--
ALTER TABLE `ims_settings_groups`
  MODIFY `groupID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `ims_users`
--
ALTER TABLE `ims_users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
